__author__ = 'ratcave'

from propixx import start_frame_sync_signal

